class Clearance::BaseController < ApplicationController
end
