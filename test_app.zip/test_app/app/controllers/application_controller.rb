class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception

  def hello
      render html:
      "<%= form_for :session, url: session_path do |form| %>
  <div class="text-field">
    <%= form.label :email %>
    <%= form.text_field :email, type: 'email' %>
  </div>

  <div class="password-field">
    <%= form.label :password %>
    <%= form.password_field :password %>
  </div>

  <div class="submit-field">
    <%= form.submit %>
  </div>

  <div class="other-links">
    <% if Clearance.configuration.allow_sign_up? %>
      <%= link_to t(".sign_up"), sign_up_path %>
    <% end %>
    <%= link_to t(".forgot_password"), new_password_path %>
  </div>
<% end %>"

    end
end
